#!/usr/bin/env python3
"""Install V7 changes into an existing CF6 Study Studio repo with a reversible local snapshot.
Run from the repository root: python3 cf6-study-studio-v7-complete/install_on_existing.py
"""
from pathlib import Path
from shutil import copy2
import json
import sys

SOURCE=Path(__file__).resolve().parent
REPO=Path.cwd().resolve()
ROLLBACK=REPO/'.cf6-v7-previous'
CHANGED=[
 'src/App.tsx',
 'src/components/PremiumLessonView.tsx',
 'src/components/RevisionCoach.tsx',
 'src/components/SyllabusFocus.tsx',
 'src/components/DailyRevision.tsx',
 'src/data/questions.ts',
 'src/data/officialCoverage.ts',
 'src/data/v7Questions.ts',
 'src/lib/engine.ts',
 'src/lib/engine.test.ts',
]

def main():
 if REPO==SOURCE:
  sys.exit('Open your existing GitHub repository folder first; do not install into the extracted ZIP itself.')
 if not (REPO/'.git').exists() or not (REPO/'src/App.tsx').exists():
  sys.exit('Open the CF6 Study Studio repository in Codespaces before running the installer.')
 if len(sys.argv)>1 and sys.argv[1]=='--restore':
  metadata=ROLLBACK/'manifest.json'
  if not metadata.exists(): sys.exit('No V7 rollback snapshot found.')
  prior=json.loads(metadata.read_text())
  for rel, existed in prior.items():
   target=REPO/rel
   if existed:
    target.parent.mkdir(parents=True,exist_ok=True)
    copy2(ROLLBACK/rel,target)
   elif target.exists():
    target.unlink()
  print('Previous files restored. Run npm test && npm run build, then commit/redeploy if desired.')
  return
 app=(REPO/'src/App.tsx').read_text(encoding='utf-8')
 if not all(marker in app for marker in ('MortgageLab','RevisionCoach','FlashcardStudio','PremiumLessonView')):
  sys.exit('Expected V6 components not detected. Installer made no changes; contact ChatGPT with your App.tsx status.')
 if not all((SOURCE/p).exists() for p in CHANGED):
  sys.exit('Incomplete V7 update ZIP; aborting without changes.')
 if ROLLBACK.exists() and not (ROLLBACK/'manifest.json').exists():
  sys.exit('Rollback directory exists without a manifest. Inspect it before continuing.')
 if not ROLLBACK.exists():
  ROLLBACK.mkdir()
  existing={}
  for rel in CHANGED:
   target=REPO/rel
   existing[rel]=target.exists()
   if target.exists():
    saved=ROLLBACK/rel
    saved.parent.mkdir(parents=True,exist_ok=True)
    copy2(target,saved)
  (ROLLBACK/'manifest.json').write_text(json.dumps(existing,indent=2))
 exclude=REPO/'.git/info/exclude'
 if exclude.exists():
  text=exclude.read_text()
  if '.cf6-v7-previous/' not in text:
   with exclude.open('a') as f: f.write('\n.cf6-v7-previous/\n')
 for rel in CHANGED:
  dst=REPO/rel
  dst.parent.mkdir(parents=True,exist_ok=True)
  copy2(SOURCE/rel,dst)
 print(f'V7 installed: {len(CHANGED)} changed files. Your previous files are in {ROLLBACK.name}/.')
 print('Next: npm test && npm run build')
 print('Only if both pass: git add src && git commit -m "Upgrade CF6 Study Studio to V7 Exam Ready" && git push origin main')
 print('To undo files (without touching IndexedDB progress): python3 cf6-study-studio-v7-complete/install_on_existing.py --restore')

if __name__=='__main__':main()
