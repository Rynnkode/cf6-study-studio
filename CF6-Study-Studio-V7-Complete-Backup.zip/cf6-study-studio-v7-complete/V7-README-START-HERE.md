# CF6 Study Studio — V7 Exam Ready

This is a **full source-code backup** of the CF6 Study Studio website based on V6, with the V7 upgrades below. It is not a copy of your personal IndexedDB study records or a one-click offline HTML export. Save this ZIP safely as your website source backup; your site can be rebuilt using Node.js and npm.

## What's new

- Official 2026–27 syllabus checklist across all 16 learning outcomes, with explanatory prompts and common traps. Tap each outcome to check your own understanding; these check marks persist locally.
- 30 new original standalone multiple-choice questions plus two five-question fictional client cases (40 new questions). Total question library: **185**; **9** case studies comprising **45** linked questions. The older questions and IDs are retained so previous saved history remains meaningful.
- Full 3-hour mock still consists of **100 standalones + five five-question cases**. Standalones are now selected by the 2026–27 indicative learning outcome distribution from the broader bank, and five case scenarios are selected without duplication.
- Daily guided 20-minute workflow: topic lesson, 10-question daily quiz, flashcard review, mistake recap and personal takeaway. Study, flashcard and recap tasks can be marked done, while the quiz completes automatically after a graded daily session. The daily plan resets each local day but prior entries remain in progress backups.
- Label missed questions in exam review as **Knowledge gap**, **Misread question** or **Calculation error**, and see a breakdown of your own labels in the revision coach. This is self-classification, never automated diagnosis.
- More visible progress export from the Home page, and a local 'last export started' indicator in Settings. Progress is still stored **only on this browser/device** until exported as JSON.
- Both old and new backups use progress schema version 1; the new fields have safe defaults for older exports.

## Exam accuracy and limitations

Checked against the **CII CF6 2026–27 syllabus published June 2026** and the **CII 2026–27 examination guide**. The syllabus specifies 100 standalone MCQs plus 5 cases × 5 questions, three hours, predominantly English law and practice for tax year 2026–27. The stated distribution is indicative with built-in flexibility. Study text and exam rules can change; verify primary sources and course updates.

All additional questions and teaching prompts are original, **unofficial** exercises, not official CII questions or live mortgage advice. The topic checklists improve coverage but do not independently certify syllabus mastery. In particular, income, tax, lender criteria and legal requirements must be checked against applicable sources.

Official syllabus: https://media.umbraco.io/ciigroup-dxp/ewpb05xv/cf6_mortgage_advice_examination_syllabus.pdf

Official guide: https://media.umbraco.io/ciigroup-dxp/vn2jci1r/cf6_examination_guide_for_exams_from_1_september_2026_to_31_august_2027.pdf

## Back up your personal progress **first**

On your normal Safari tab/Home Screen app, open **Settings & data → Export JSON backup** and save the JSON to Files or iCloud Drive. The site ZIP does not include your answers, completed lessons or flashcard review history. Do not delete Safari website data, clear IndexedDB or uninstall your Home Screen app during this process. Private Browsing has independent storage and is not a reliable place for persistent study data.

## Install V7 in existing GitHub Codespaces

1. Save this ZIP on your device, then upload it into the *root* of https://github.com/Rynnkode/cf6-study-studio (using the GitHub Add file → Upload files interface). You can keep the ZIP as your local archive as well.
2. Open **Code → Codespaces**, and from the repository Terminal run:

```bash
git pull --rebase origin main
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile
files=sorted(Path('.').glob('CF6-Study-Studio-V7-Complete-Backup*.zip'),key=lambda p:p.stat().st_mtime)
if not files: raise SystemExit('Upload the V7 ZIP first.')
with ZipFile(files[-1]) as z: z.extractall('.')
print('V7 package extracted')
PY
python3 cf6-study-studio-v7-complete/install_on_existing.py
npm test && npm run build
```

3. **Only if both test and build pass**, run:

```bash
git add src
git commit -m "Upgrade CF6 Study Studio to V7 Exam Ready"
git push origin main
```

4. Wait for GitHub Actions Build and Deploy to show green ticks. Reopen your normal Safari site at https://rynnkode.github.io/cf6-study-studio/. If it looks stale, open a *separate temporary Private tab* only to inspect the version — never use it for long-term saving.

### If there is an error

Stop before `git push`. Send the last 15–25 lines of the Terminal error. The installer snapshots the prior versions of the 10 changed source files in `.cf6-v7-previous/`. To restore them:

```bash
python3 cf6-study-studio-v7-complete/install_on_existing.py --restore
npm test && npm run build
```

This is a code rollback only. It does not modify browser-saved learning progress.

## Rebuild the site from this backup alone

Extract `cf6-study-studio-v7-complete`, open it as a Node.js project, run `npm install`, `npm test`, and `npm run build`. Compiled static assets appear in `dist/` only after a successful build. The repository includes a GitHub Actions Pages workflow.

## Validation completed outside Codespaces

- 30 TypeScript/TSX application files passed TypeScript syntax/transpilation checks.
- Verified the original 100 standalone structure, 185 unique questions overall, 9 cases and 45 linked case questions, and no question-bank validation errors.
- Exercised 40 generated full-mock sessions to check question uniqueness, 100+25 structure, case selection and learning-outcome weighting.
- Confirmed the new progress fields can fall back safely when loading a legacy V6 progress object.

**Limitation:** The full `npm test && npm run build` in this environment could not be executed because dependency installation from npm is unavailable. Codespaces must complete these checks before you publish. The ZIP is a full source backup, not a tested compiled release.
