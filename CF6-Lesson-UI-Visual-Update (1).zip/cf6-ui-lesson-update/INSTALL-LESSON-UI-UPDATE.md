# CF6 Study Studio — Lesson UI & visual learning update

This update redesigns the lesson view to make content less text-heavy and more interactive on mobile and desktop.

## What this update changes

- Replaces the old long lesson page with a tabbed lesson experience:
  - **Learn**
  - **Visualise**
  - **Worked example**
  - **Knowledge check**
- Breaks lesson notes into expandable sections instead of long continuous text blocks.
- Adds richer side panels for:
  - definitions
  - key points
  - exam traps
- Adds visual learning components for high-value topics, including:
  - property purchase timeline
  - survey comparison table
  - affordability chart
  - debt consolidation comparison
  - ownership comparison cards
  - mortgage product comparison chart
  - repayment vs interest-only chart
- Keeps your current saved progress structure intact.

## Before you install

Export a backup from the app first as a precaution.

## Install in GitHub Codespaces

Upload `CF6-Lesson-UI-Visual-Update.zip` to the root of your repository, then in the terminal run:

```bash
git pull
unzip -o CF6-Lesson-UI-Visual-Update.zip
npm test
npm run build
```

If both commands succeed, commit and push:

```bash
git add src/App.tsx
git commit -m "Improve lesson UI with visual and interactive study layout"
git push
```

## Notes

- This update replaces `src/App.tsx` only.
- It is designed to work with the current CF6 Study Studio structure, including the expanded lessons update.
- Your lesson completion and progress data should remain unchanged.
