"""Install the combined V6/V7/V8 UI and engine onto an existing CF6 Study Studio repository.
This does not read or modify saved browser/IndexedDB data.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from datetime import datetime
import shutil, sys

package=Path(__file__).resolve().parent
repo=Path.cwd().resolve()
if repo == package:
    raise SystemExit('Run this from your existing CF6 repository root, not inside the backup folder.')
required=['src/App.tsx','src/components/FlashcardStudio.tsx','src/lib/engine.ts','src/data/questions.ts','package.json']
missing=[name for name in required if not (repo/name).is_file()]
if missing:
    raise SystemExit('This folder is not the existing CF6 app. Missing: '+', '.join(missing))
current=(repo/'src/App.tsx').read_text()
if 'PremiumHome' not in current or 'FlashcardStudio' not in current:
    raise SystemExit('Expected V5 app not found. Installation stopped to protect your current project.')
changed=[
 'src/App.tsx',
 'src/components/MortgageLab.tsx',
 'src/components/RevisionCoach.tsx',
 'src/components/ExamPrepPanel.tsx',
 'src/components/PremiumHome.tsx',
 'src/components/PremiumLessonView.tsx',
 'src/lib/engine.ts',
 'src/lib/studyCoach.ts',
 'src/lib/mortgageLab.ts',
 'src/lib/studyCoach.test.ts',
 'src/lib/mortgageLab.test.ts',
 'src/lib/engine.test.ts',
 'src/data/questions.ts',
 'vite.config.ts',
]
for name in changed:
    if not (package/name).is_file():
        raise SystemExit(f'Update package is incomplete: {name}')
old=[name for name in changed if (repo/name).exists()]
backup=repo/f'CF6-pre-v6-code-backup-{datetime.now().strftime("%Y%m%d-%H%M%S")}.zip'
with ZipFile(backup,'w',compression=ZIP_DEFLATED) as z:
    for name in old:
        z.write(repo/name,name)
for name in changed:
    destination=repo/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(package/name,destination)
print('Installed combined V6-V8 update into the existing app.')
print('Original code backup:',backup.name)
print('Only code was changed. Existing browser study progress was not accessed.')
print('Next: npm test && npm run build')
