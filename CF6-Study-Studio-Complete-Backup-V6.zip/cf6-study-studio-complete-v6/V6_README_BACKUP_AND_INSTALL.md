# CF6 Study Studio – Integrated V6 update & complete project backup

This folder is a **complete source-code snapshot** of CF6 Study Studio, plus a separate installer for applying the updated files to your existing GitHub repository. It is not the compiled `dist/` website and it does not contain your personal browser study history.

## What's included

- **Mortgage Lab**: repayments, overpayments, rate shocks, loan-to-value and budget resilience, with live charts and worked advice implications.
- **Exam Centre upgrade**: 20-question timed sprint (20-minute timer), 15-question adaptive challenge, two extra five-question original linked client cases, existing full 125-question CF6-style simulation retained.
- **Revision Coach**: topic priorities that consider indicative exam weighting, answer accuracy, coverage and recency; interactive topic actions and weekly practice charts. This is a heuristic, not a CII pass probability.
- **Lesson integration**: a link from visual lesson content to the new Mortgage Lab. Existing original content, interactive activities, flashcards and tests are retained.
- **Automatic PWA updates**: configured to activate fresh deployments rather than relying on manual update prompts.

## Back up your personal progress FIRST

Your course and test results live in your device's local browser database, **not in the website source**. The ZIP cannot include them. On the existing website, use **Settings & Data → Export backup (JSON)**; save that JSON to Files or Dropbox. This is separate from this source-code backup. Keep it private. The app's Restore backup option can import it on a new browser/device.

## Install the update on your existing Codespace

1. Upload the **outer ZIP** (`CF6-Study-Studio-Complete-Backup-V6.zip`) into the root of your `cf6-study-studio` GitHub repository.
2. Open the GitHub Codespace Terminal in the repository root.
3. Make sure changes in Codespaces are committed or backed up, then run:

```bash
git pull --rebase origin main
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile
files=sorted(Path('.').glob('CF6-Study-Studio-Complete-Backup-V6*.zip'),key=lambda p:p.stat().st_mtime)
if not files:
    raise SystemExit('Please upload the ZIP to the repo root first.')
with ZipFile(files[-1]) as z:
    z.extractall('.')
print('Extracted full-site backup and installer')
PY
python3 cf6-study-studio-complete-v6/install_on_existing.py
npm test && npm run build
```

4. **Only if tests and build both pass**, run:

```bash
git add src/App.tsx src/components src/data/questions.ts src/lib vite.config.ts
git commit -m "Combine mortgage lab, exam centre and revision coach"
git push origin main
```

5. Wait for GitHub Actions **Build** and **Deploy** to succeed. Open the existing site in Safari.

The installer creates a `CF6-pre-v6-code-backup-YYYYMMDD-HHMMSS.zip` file containing the original overwritten code, so you can restore it if needed. Do **not** publish this backup ZIP to GitHub unless you intend to store the old code there; the installer does not add it to Git.

## Save a deployable built-site ZIP (optional)

The outer backup contains everything required to rebuild the website when NPM packages are available. To create a separate ZIP of the compiled static website in Codespaces, after successfully running `npm run build`, run:

```bash
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path('dist')
if not (root/'index.html').exists():
    raise SystemExit('Run npm run build first')
with ZipFile('CF6-Compiled-Website-Backup.zip','w',ZIP_DEFLATED) as z:
    for path in root.rglob('*'):
        if path.is_file(): z.write(path,path.relative_to(root))
print('Created CF6-Compiled-Website-Backup.zip')
PY
```

Keep that ZIP as your **static-site deployable backup**. It will not contain personally saved lesson completion, flashcard ratings or test results. Static assets must be hosted on an HTTP(S) server for PWA behaviour.

## Standalone source backup

You can unzip this archive on another computer, navigate into `cf6-study-studio-complete-v6` and run:

```bash
npm install
npm test
npm run build
npm run dev
```

Node.js 22+ recommended. Existing `.github/workflows/pages.yml` is included. This backup is for an unofficial educational app and its practice materials are not CII examinations or live lender criteria.
