# CF6 Study Studio — Deeper lessons, first teaching expansion

This update expands all 16 **existing** CII CF6 2026–27 outcomes with 98 original instructional sections (approximately 4,363 additional words). Topics include regulation, conveyancing, survey and defect risks, borrower types, affordability, costs and taxes, protection, remortgaging, debt consolidation, arrears, state support, ownership, product selection, amortisation and applied case analysis. It is a **first expansion**, not yet the planned 40 separate modules or an independently peer-reviewed textbook replacement.

## Install on GitHub Codespaces

Upload `CF6-Deeper-Lessons-v1.zip` to the repository root, reopen Codespaces, then:

```bash
git pull
unzip -o CF6-Deeper-Lessons-v1.zip
python3 cf6-lessons-v2/install.py
npm test
npm run build
```

Only if both tests and build succeed:

```bash
git add src/data/syllabus.ts src/data/expandedLessons.ts
git commit -m "Expand all 16 CF6 learning outcomes"
git push
```

The lesson IDs remain `lo1`–`lo16` so existing completion flags remain intact. The question database and flashcard scheduler are unchanged. Always export progress to JSON before updating as a precaution. Existing lesson completion will not be reset; manually revisit completed lessons to read their new sections.

## Scope and currency

The 2026–27 edition of CII CF6 applies to exams 1 September 2026–31 August 2027. Content is original and unofficial. Check the CII live web updates plus current FCA MCOB and official tax scheme pages for changed figures. This release avoids unverified current SDLT thresholds and live lender criteria.

Sources and further study:
- https://www.cii.co.uk/learning/qualifications/unit-mortgage-advice-cf6/
- https://www.handbook.fca.org.uk/handbook/MCOB/
- https://www.gov.uk/government/organisations/hm-revenue-customs
- https://www.rics.org/
- https://www.moneyhelper.org.uk/

Next phase would subdivide each outcome into individually tracked micro-lessons with richer tables, multiple case calculations and embedded checks. This release uses the current 16-lesson renderer, with no database migration.
