from pathlib import Path
root=Path(__file__).resolve().parent
repo=root.parent
source=repo/'src/data/syllabus.ts'
addition=root/'src/data/expandedLessons.ts'
assert source.exists(), 'Run this from the repository root after unzipping.'
assert addition.exists(), 'Expanded lessons source is missing.'
s=source.read_text()
if "import { expandedLessons } from './expandedLessons';" not in s:
    s="import { expandedLessons } from './expandedLessons';\n"+s
if 'export const lessons:Lesson[]=[' in s:
    s=s.replace('export const lessons:Lesson[]=[','const baseLessons:Lesson[]=[',1)
if 'export const lessons:Lesson[] = baseLessons.map' not in s:
    s+='\n// Preserve existing lo1..lo16 identifiers so locally saved lesson completion survives.\nexport const lessons:Lesson[] = baseLessons.map(lesson => ({\n  ...lesson,\n  notes: [...lesson.notes, ...(expandedLessons[lesson.lo] ?? [])]\n}));\n'
source.write_text(s)
target=repo/'src/data/expandedLessons.ts'
target.write_text(addition.read_text())
print('Installed extended lessons for 16 outcomes. Existing lesson IDs preserved.')
