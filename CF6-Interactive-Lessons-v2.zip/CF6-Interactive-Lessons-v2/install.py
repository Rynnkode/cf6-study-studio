from pathlib import Path
p=Path('src/App.tsx')
if not p.exists():
    raise SystemExit('Run from the GitHub repository root: src/App.tsx missing')
s=p.read_text()
if '<LessonVisual lesson={lesson}/>' not in s:
    raise SystemExit('The visual-lesson release is missing: expected LessonVisual marker not found. No changes made.')
if "import LessonActivities from './components/LessonActivities'" not in s:
    s="import LessonActivities from './components/LessonActivities';\n"+s
if '<LessonActivities key={lesson.id} lo={lesson.lo}/>' not in s:
    s=s.replace('<LessonVisual lesson={lesson}/>','<LessonVisual lesson={lesson}/><LessonActivities key={lesson.id} lo={lesson.lo}/>',1)
# Add a compact knowledge retrieval exercise after the first open reading block, without affecting saved lesson IDs.
if 'Learn actively: try explaining' not in s:
    s=s.replace('</summary><div className="mt-4 space-y-4">{group.map', '</summary><div className="mt-4 space-y-4"><div className="rounded-xl border border-[#dce7dc] bg-[#eef6ee] p-3 text-sm font-semibold text-[#205747]">Learn actively: try explaining this section aloud before you read the notes below.</div>{group.map',1)
p.write_text(s)
print('Installed interactive learning activities for all 16 outcomes.')
