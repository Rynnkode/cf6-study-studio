# CF6 Study Studio — Interactive Lessons v2

Adds **16 unique mini client decision exercises** with immediate explanatory feedback, clickable three-step learning diagrams, and a more active reading prompt. These supplement (not replace) the existing Visualise charts and comparative visuals. Fully local: no APIs, images downloaded at runtime, or new database schema.

## Installation in GitHub Codespaces

Export your progress JSON first. Upload `CF6-Interactive-Lessons-v2.zip` to the repository root, then:

```bash
git pull
unzip -o CF6-Interactive-Lessons-v2.zip
python3 CF6-Interactive-Lessons-v2/install.py
npm test
npm run build
```

Only if both checks pass:

```bash
git add src/App.tsx src/components/LessonActivities.tsx
git commit -m "Add interactive client exercises across CF6 lessons"
git push
```

Check **Study → any lesson → Visualise** to try the new interactive process diagram and decision exercise. Test on your iPhone once GitHub Actions has completed its deploy.

The activities are original, unofficial study examples; not live lender criteria or personal mortgage advice. Scored exam practice remains separate in Knowledge Check. Existing data and lesson IDs are unchanged.
