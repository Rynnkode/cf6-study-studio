# CF6 Study Studio — Premium Learning + Flashcards v5

A focused upgrade for the existing **CF6 Study Studio v4** project on GitHub Pages. **This is not a new app**: your existing IndexedDB progress database, saved mocks, question bank, syllabus and PWA configuration are left unchanged.

## What changes

**Lesson readability**
- Stronger, separate borders around lesson concept and green/amber callout areas.
- Clearer dark text on white/pale backgrounds; bold headings and exam-key sentences.
- Tap-to-open Learn sections and tap-to-reveal key takeaways.
- Two original, topic-specific True/False knowledge checks in **every one of the 16 learning outcomes**, with immediate explanations. These informal checks do not change graded mock data.
- Keeps the existing calculators, clickable process diagrams, comparison dropdowns and client exercises in the Explore and Try tabs.

**Flashcards**
- Redesigned flashcard screen with compact due/review/mastery metrics.
- Three functioning modes: Due review, **10 random unique cards**, and All cards, with optional learning outcome filter.
- A stable card list per session so reviewing a card does not unexpectedly reorder or skip the others.
- Tap a card to reveal the answer, then choose Again / Hard / Good / Easy; ratings update spaced-repetition scheduling in IndexedDB.
- **Study lesson: LO X** opens the corresponding lesson directly; for recall cards, optionally expand **Why is this the right answer?** to see the original question explanation.
- Reset **current card**, **topic's reviewed cards** or **all flashcard ratings** with a confirmation. Resets leave mock results, completed lessons and other saved study data untouched.
- No account, external API, AI service or subscription is needed.

## Install on GitHub Codespaces

1. **Before updating:** Open the app in normal Safari, visit Settings & Backup, and export a JSON progress backup. Keep it in Files/iCloud Drive.
2. Upload `CF6-Premium-Learning-Flashcards-v5.zip` to the root of your GitHub repository using **Add file → Upload files → Commit changes**.
3. Open the existing Codespace. From the project root (where `package.json` lives), run:

```bash
git pull --rebase origin main
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile
matches=sorted(Path('.').glob('CF6-Premium-Learning-Flashcards-v5*.zip'),key=lambda x:x.stat().st_mtime)
if not matches: raise SystemExit('Upload the v5 ZIP to GitHub first.')
with ZipFile(matches[-1]) as z: z.extractall('.')
print('Unpacked',matches[-1])
PY
python3 cf6-premium-v5/install.py
npm test && npm run build
```

4. **Only if tests and build succeed**, publish:

```bash
git add src/App.tsx src/components/FlashcardStudio.tsx src/components/PremiumLessonView.tsx src/lib/flashcardSession.ts src/lib/flashcardSession.test.ts src/data/lessonMicroChecks.ts
git commit -m "Improve premium lessons and add flashcard review modes"
git push origin main
```

5. Wait for **Build** and **Deploy** to turn green in GitHub Actions, then open https://rynnkode.github.io/cf6-study-studio/ in normal Safari.

**Note:** Uploading the ZIP alone does not install the update. The installer is safe to rerun. Stop and share any errors before committing.

## Quick acceptance checklist

- Home dashboard shows the existing v4 design.
- Study → LO2 → Learn: at least two brief True/False self-checks appear inside expandable lesson sections.
- Study → LO5 → Explore: the rate-shock calculator responds to sliders.
- Flashcards → **10 random**: 10 different cards with a visible progress indicator.
- Tap to reveal an answer, rate it, and verify you move to the next card.
- Study lesson opens the right LO and keeps your flashcard rating history.
- Flashcards → Reset cards: can reset current card, topic, or all with confirmation.
- Existing mock history and lesson completion remain after reopening the app.

## Testing

`src/lib/flashcardSession.test.ts` adds automated tests for unique random selections and selective reset behavior. The existing tests remain in place. Run `npm test && npm run build` in Codespaces **before publishing**. The build was not run inside the packaging environment where required npm dependencies are unavailable.
