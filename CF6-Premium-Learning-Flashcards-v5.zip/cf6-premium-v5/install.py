#!/usr/bin/env python3
"""Non-destructive integration of CF6 v5 flashcards and premium lesson presentation.

Run in the existing cf6-study-studio repository root after unpacking the ZIP.
No saved IndexedDB data, mock history, question bank or syllabus is touched.
"""
from pathlib import Path
import re

root=Path.cwd()
app=root/'src/App.tsx'
package=root/'package.json'
source_dir=Path(__file__).resolve().parent
if not app.is_file() or not package.is_file():
    raise SystemExit('ERROR: Run from your cf6-study-studio project root (where package.json is).')
s=app.read_text(encoding='utf-8')
if "import PremiumHome from './components/PremiumHome'" not in s or "import {PremiumLessonView} from './components/PremiumLessonView'" not in s:
    raise SystemExit('ERROR: v4 is not detected. No files modified. Install and deploy v4 first.')

if "import FlashcardStudio from './components/FlashcardStudio'" not in s:
    missing=[mark for mark in ["{page==='Flashcards'&&<>","{page==='Progress'&&","const [flashLo,setFlashLo]",'function gradeCard(', 'const dueFiltered='] if mark not in s]
    if missing:
        raise SystemExit('ERROR: Unexpected App.tsx structure. No files changed. Missing: '+', '.join(missing))
    original=s
    s="import FlashcardStudio from './components/FlashcardStudio';\nimport {resetCardRecords} from './lib/flashcardSession';\n"+s
    state=re.compile(r"const \[flashLo,setFlashLo\]=useState\(0\);const \[flashShowAll,setFlashShowAll\]=useState\(false\);const \[flashIndex,setFlashIndex\]=useState\(0\);const \[revealed,setRevealed\]=useState\(false\);")
    s,count=state.subn('',s,count=1)
    if count!=1:raise SystemExit('ERROR: Flashcard state mismatch. No changes made.')
    grade=re.compile(r'function gradeCard\(id:string,rating:Rating\)\{[^\n]*\}')
    newgrade="function gradeCard(id:string,rating:Rating){setP(x=>({...x,cards:{...x.cards,[id]:nextCard(x.cards[id],rating)},lastStudyDate:today()}))}"
    s,count=grade.subn(newgrade,s,count=1)
    if count!=1:raise SystemExit('ERROR: Flashcard grading code mismatch. No changes made.')
    due=re.compile(r'const dueFiltered=flashShowAll\?[^\n]*\n')
    s,count=due.subn('',s,count=1)
    if count!=1:raise SystemExit('ERROR: Old flashcard list code mismatch. No changes made.')
    start=s.index("{page==='Flashcards'&&<>")
    end=s.index("{page==='Progress'&&",start)
    component="""{page==='Flashcards'&&<FlashcardStudio progress={p} onGrade={gradeCard} onReset={ids=>setP(current=>resetCardRecords(current,ids))} onOpenLesson={id=>{setLessonId(id);setPage('Study');window.scrollTo(0,0)}}/>}\n"""
    s=s[:start]+component+s[end:]
    s=s.replace('amortisation,beginSession,cards,dueCards','amortisation,beginSession,dueCards',1)
    # The previous flashcard screen was the only remaining user of this icon.
    s=s.replace(',Bookmark,CheckCircle2,}',',Bookmark,}',1)
    if s==original or "const [flashLo" in s or 'const dueFiltered=' in s:
        raise SystemExit('ERROR: Patch verification failed. No files changed.')
    print('Prepared flashcard route update in App.tsx')
else:
    print('Flashcard routing already present; skipping duplicate patch')

# Validate all package files before writing any file.
files=['src/components/FlashcardStudio.tsx','src/components/PremiumLessonView.tsx','src/lib/flashcardSession.ts','src/lib/flashcardSession.test.ts','src/data/lessonMicroChecks.ts']
for f in files:
    if not (source_dir/f).is_file():
        raise SystemExit(f'ERROR: Update file missing: {f}; nothing installed.')
for f in files:
    target=root/f
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((source_dir/f).read_bytes())
app.write_text(s,encoding='utf-8')
print('CF6 Premium Learning + Flashcards v5 installed.')
print('Local study progress is unchanged. Next: npm test && npm run build')
