#!/usr/bin/env python3
"""Install the CF6 Premium UI update without replacing saved data or the full app."""
from pathlib import Path
import sys

project = Path.cwd()
p = project / 'src/App.tsx'
if not p.exists():
    raise SystemExit('Run from the cf6-study-studio project root (where package.json lives).')
source = p.read_text()
if "import {PremiumHome} from './components/PremiumHome'" in source:
    raise SystemExit('Premium UI v4 appears to be installed already. No files changed.')

# Check all expected anchors BEFORE making any change.
markers = ["{page==='Home'&&<>","{page==='Study'&&!lesson&&<>","{page==='Study'&&lesson&&", "{page==='Practice'&&",'function Task(', 'function PracticeCard(']
missing = [m for m in markers if m not in source]
if missing:
    raise SystemExit('Application layout does not match the expected version; no changes made. Missing: ' + ', '.join(missing))

h0=source.index("{page==='Home'&&<>")
h1=source.index("{page==='Study'&&!lesson&&<>",h0)
s1=source.index("{page==='Study'&&lesson&&",h1)
if not h0 < h1 < s1:
    raise SystemExit('Page anchors out of order; no files changed.')

home = """{page==='Home'&&<PremiumHome progress={p} suggested={suggested} completed={completed} currentDay={currentDay} daysToExam={daysToExam} attempts={attempts} accuracy={accuracy} streak={streak} studyTimeSeconds={p.studySeconds} due={due} unresolved={unresolved} ready={ready} strongest={strongest} weakest={weakest} onLesson={id=>{setLessonId(id);setPage('Study');window.scrollTo(0,0)}} onDaily={()=>launch('daily',10)} onFlashcards={()=>changePage('Flashcards')} onMistakes={()=>{changePage('Practice');setTopic(-1)}} onResult={id=>{setViewResult(id);setPage('Practice')}} onProgress={()=>changePage('Progress')} onStudy={()=>changePage('Study')}/>}\n"""
study = """{page==='Study'&&!lesson&&<PremiumStudyProgramme completed={p.completed} search={search} onSearch={setSearch} onOpen={id=>{setLessonId(id);window.scrollTo(0,0)}}/>}\n"""
source=source[:h0]+home+study+source[s1:]

source="import PremiumHome from './components/PremiumHome';\nimport PremiumStudyProgramme from './components/PremiumStudyProgramme';\n"+source
# Previous Home used CalendarDays; the new component imports it itself.
source=source.replace(',CalendarDays,ArrowRight',',ArrowRight')
source=source.replace(',Search,Settings',',Settings')
# Task was used only by old Home; PracticeCard is still required for mocks.
t0=source.index('function Task(')
t1=source.index('function PracticeCard(',t0)
source=source[:t0]+source[t1:]

srcdir=Path(__file__).resolve().parent / 'src/components'
dstdir=project/'src/components'
dstdir.mkdir(parents=True,exist_ok=True)
for name in ['PremiumHome.tsx','PremiumStudyProgramme.tsx','ConceptLab.tsx','PremiumLessonView.tsx']:
    (dstdir/name).write_bytes((srcdir/name).read_bytes())
extra=dstdir/'LessonActivities.tsx'
if not extra.exists():
    extra.write_bytes((srcdir/'LessonActivities.tsx').read_bytes())
p.write_text(source)
print('Installed CF6 Premium UI v4 components and updated Home/Study routing.')
print('Your IndexedDB data, mocks, flashcards, and lesson IDs have not been changed.')
print('Next: npm test && npm run build')
