# CF6 Premium UI v4 — Home + Lesson redesign

This update is built for the current **CF6 Study Studio** GitHub project. It deliberately does not replace the app's storage, question bank, mock engines or lesson IDs.

## Changes
- Home: designed daily focus hero, compact live stats, actionable daily routine, real seven-day quiz activity bar chart, personal weak topic suggestions and real mock results.
- Study index: compact week accordions, live progress, search and filters, next-lesson CTA.
- Lessons: compact summary header, four equal-width tabs, expandable learning notes, clickable definitions and reveal-takeaways.
- Visualise: interactive three-stage flows, genuinely interactive topic lab for each of 16 outcomes, expandable exam comparisons; removes the static green illustrated memory board.
- Try it: 16 linked client micro-scenarios and existing scored five-question knowledge checks.
- Responsive mobile controls, clearer borders, accessible labels and keyboard focus states.

No fake stats or fabricated live lender criteria. Financial scenarios are illustrative. The existing CII syllabus content and existing data have not been changed.

## Install
1. Export your study progress as JSON in **Settings & backup** before making any update.
2. Upload the ZIP to the **root** of your GitHub repository. GitHub may rename it with `(1)`; this is okay.
3. Open GitHub Codespaces, in your project root.
4. Run:

```bash
git pull --rebase origin main
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile
zips=sorted(Path('.').glob('CF6-Premium-UI-v4*.zip'),key=lambda p:p.stat().st_mtime)
if not zips: raise SystemExit('Upload CF6-Premium-UI-v4.zip to the repository first.')
with ZipFile(zips[-1]) as z: z.extractall('.')
print('Extracted:',zips[-1])
PY
python3 cf6-premium-ui-v4/install.py
npm test && npm run build
```

5. **Only if all tests and the build succeed:**

```bash
git add src/App.tsx src/components/PremiumHome.tsx src/components/PremiumStudyProgramme.tsx src/components/ConceptLab.tsx src/components/PremiumLessonView.tsx src/components/LessonActivities.tsx
git commit -m "Redesign CF6 Home and interactive lessons"
git push origin main
```

6. Wait for **Build** and **Deploy** green ticks in GitHub Actions, then check: https://rynnkode.github.io/cf6-study-studio/

## Notes
- The install script checks expected source markers before modifying files. If these are missing, it stops without applying the patch.
- The update replaces only UI components and two page-rendering segments in App.tsx; no data migration.
- Some devices may cache the old PWA interface until reload. Export progress before removing any installed Home Screen web app.
- Install routine is designed to be run once.
