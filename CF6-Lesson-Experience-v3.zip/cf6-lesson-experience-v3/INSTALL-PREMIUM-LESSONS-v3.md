# CF6 Lesson Experience v3 — Premium lesson overhaul

This update upgrades the **lesson experience across all 16 outcomes**.

## What this adds
- Premium lesson header and summary cards
- Consistent lesson tabs: **Learn / Visualise / Worked example / Try it**
- Chunked learning notes instead of one long text block
- Interactive **tap-to-reveal stage flows**
- Comparison cards and visual memory panels in every lesson
- Better definition handling, advisor-lens callouts and revision prompts
- Cleaner mobile-first lesson UI with more intentional structure

## Files included
- `src/App.tsx`
- `src/components/PremiumLessonView.tsx`

---

## Fast install (recommended in Codespaces / terminal)
From your project root:

```bash
unzip -o CF6-Lesson-Experience-v3.zip
git add src/App.tsx src/components/PremiumLessonView.tsx
git commit -m "Upgrade all lessons to premium lesson experience v3"
git push
```

Then wait for GitHub Pages to deploy.

---

## If you are uploading manually in GitHub
Open your repo and upload/replace:
- `src/App.tsx`
- `src/components/PremiumLessonView.tsx`

Then commit the changes.

---

## Notes
- This update is focused on the **Study lessons**.
- Practice, flashcards, progress and calculator features remain intact.
- If GitHub Pages shows the old version, hard refresh or re-open the site after deployment finishes.
